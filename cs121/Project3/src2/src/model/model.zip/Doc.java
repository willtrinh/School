package model;

import java.io.File;
import java.io.IOException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

public class Doc {
	private String id;
	private String url;
	final private String rootPath = "WEBPAGES_RAW";
	
	public Doc(String id, String url) {
		super();
		this.id = id;
		this.url = url;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	
	public Document loadFile() throws IOException {
		String filepath = rootPath + "/" + id;
		File input = new File(filepath);
		Document doc = Jsoup.parse(input, "UTF-8", url);
		return doc;
	}
	
	public String getText() throws IOException {
		return loadFile().text();
	}
	
	public String[] getTerms() throws IOException {
		return getText().split("(\\W+|_+)");
	}
}
