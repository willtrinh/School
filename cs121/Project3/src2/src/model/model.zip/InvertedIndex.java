package model;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Set;
import com.google.gson.Gson;

public class InvertedIndex extends LinkedHashMap<String, PostingList> {

	private static final long serialVersionUID = -3799322616058784998L;

	public InvertedIndex() {
		super();
	}
	
	public void feed(Doc doc) throws IOException
	{
		String[] terms = doc.getTerms();
		for (String term : terms)
		{
			put(term, doc);
		}
	}
	
	public void put(String term, Doc doc) {
		if (containsKey(term))
			get(term).addOrUpdateDoc(doc);
		else
			put(term, new PostingList(doc));
	}

	public Set<String> getAllTerms() {
		return keySet();
	}
	
	public Collection<Doc> getDocs(String term) {
		if (containsKey(term))
			return get(term).getDocs();
		return null;
	}
	
	public ArrayList<String> getURLs(String term) {
		if (containsKey(term))
			return get(term).getURLs();
		return null;
	}
	
	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		InvertedIndex index = new InvertedIndex();
		
		Gson gson = new Gson();
		
		try {
			BufferedReader br = new BufferedReader(new FileReader("WEBPAGES_RAW/bookkeeping.json"));
			LinkedHashMap<String, String> obj = gson.fromJson(br, LinkedHashMap.class);
			int i = 0;
			for (String id : obj.keySet())
			{
				i++;
				System.out.println(i + " - Feeding page " + id);
				index.feed(new Doc(id, obj.get(id)));
			}		
			System.out.println("Finished feeding " + i + " pages.");
			
			// Print out the index
			for (String term : index.getAllTerms())
			{
				System.out.print("Term " + term);
				for (Doc page : index.getDocs(term))
				{
					System.out.print(" -- " + page.getId());
				}
				System.out.println();
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
