/**
 * 
 */
package model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;

/**
 * @author An Le
 *
 */
public class PostingList extends LinkedHashMap<String, Doc> {
	private static final long serialVersionUID = 1633571716190811826L;

	public PostingList() {
		super();
	}
	
	public Doc getDoc(String id) {
		return get(id);
	}
	
	public PostingList(Doc doc) {
		super();
		addOrUpdateDoc(doc);
	}

	public void addOrUpdateDoc(Doc doc) {
		put(doc.getId(), doc);
	}
	
	public Collection<Doc> getDocs() {
		return values();
	}
	
	public ArrayList<String> getURLs() {
		ArrayList<String> list = new ArrayList<String>();
		for (Doc doc : values())
		{
			list.add(doc.getUrl());
		}
		return list;		
	}
}
