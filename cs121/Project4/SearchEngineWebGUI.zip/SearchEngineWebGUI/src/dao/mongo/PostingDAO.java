package dao.mongo;

import model.Posting;

public class PostingDAO extends BasicDAO {

	public PostingDAO() {
		super("Posting");
	}

	public void addPosting(String term, Posting posting)
	{
		
	}
	
	public void updatePosting(String term, Posting posting)
	{
		
	}
	
	public Posting getPosting(String term, String docId)
	{
		return null;
	}
}
