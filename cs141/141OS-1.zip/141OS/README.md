141OS is a very simple operating system that allows multiple users to save and print files.

- Goal: The goal of the system is to exploit possible parallelism to keep the devices (disks and printers) as busy as possible.

- makefile:
+ to run:
	$ make
+ to clean .class files + outputs:
	$ make clean

- inputs/outputs files path are located in UserThread.java and Printer.java
+ inputs path is currently set to: "inputs/"
+ outputs path is currently set to: "outputs/"

