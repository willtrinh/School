// DiskManager keeps track of the next free sector on each disk
// and to contain DirectoryManager for finding file sectors on Disk.
class DiskManager
{
    DirectoryManager dm = new DirectoryManager();

    public static int getNextSector(int disk)
    {
        return OS.disks[disk].currentSector;
    }
}
