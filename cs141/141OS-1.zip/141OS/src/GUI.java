import java.awt.*;
import javax.swing.*;


class GUI extends JFrame
{
    private Thread t = new Thread();


    private static void addLabel(String txt, Container c, JLabel[] arr, int idx) {
        JLabel label = new JLabel(txt);
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        arr[idx] = label;
        c.add(label);
    }

    static void updatePanel(String text, JLabel label)
    {
        label.setText(text);
        label.setForeground(Color.red);
    }

    static void updatePanelInactive(String text, JLabel label)
    {
        label.setText(text);
        label.setForeground(Color.black);
    }

    private static void addUserToPanel(Container c){
        c.setLayout (new BoxLayout(c, BoxLayout.Y_AXIS));

        for (int i=0; i<4; i++)
        {
            String user = "User " + (i+1) + ": Inactive";
            addLabel (user, c, OS.userUI, i);
        }
    }

    private static void addDiskToPanel(Container c){
        c.setLayout (new BoxLayout(c, BoxLayout.Y_AXIS));

        for (int i=0; i<2; i++)
        {
            String disk = "Disk " + (i+1) + ": Inactive";
            addLabel (disk, c, OS.diskUI, i);
        }
    }

    private static void addPrinterToPanel(Container c){
        c.setLayout (new BoxLayout(c, BoxLayout.Y_AXIS));
        
        for (int i=0; i<3; i++)
        {
            String printer = "Printer " + (i+1) + ": Inactive";
            addLabel (printer, c, OS.printerUI, i);
        }
    }


    static void createGUI() {
        //GUI gui = new GUI();
        //Starting Frame
        JFrame f = new JFrame("CS 141OS Simulator");
        f.setLayout(null);
        f.setSize(600,400);

        //Title Image
        JLabel title = new JLabel("");
        Toolkit t = Toolkit.getDefaultToolkit();
        Image titleImg = t.getImage("resources/title.png");
        title.setIcon(new ImageIcon(titleImg));
        title.setBounds(50,10,600,100);
        f.add(title);

        // GUI Icon
        Image icon = Toolkit.getDefaultToolkit().getImage("resources/operating-system.png");
        f.setIconImage(icon);

        // Start Button
        JButton start = new JButton(new ImageIcon("resources/start_button.png"));
        start.setBounds(130,215,275,110);
        f.add(start);
        f.setVisible(true);

        //Simulator Frame
        JFrame f2 = new JFrame("CS 141OS Simulator");
        f2.setLayout(null);
        Image icon2 = Toolkit.getDefaultToolkit().getImage("resources/operating-system.png");
        f2.setIconImage(icon2);
        f2.setSize(600,400);
        start.addActionListener(e -> {
                f.setVisible(false);
                f2.setVisible(true);
        });

        // User Panel
        JPanel userPanel = new JPanel();
        userPanel.setBounds(100,20,400,100);
        f2.add (userPanel);
        addUserToPanel(userPanel);

        // User Icon
        Toolkit t2 = Toolkit.getDefaultToolkit();
        JLabel userL = new JLabel("");
        Image userImg = t2.getImage("resources/user1.png");
        userL.setIcon(new ImageIcon(userImg));
        userL.setBounds(10,0,100,100);
        f2.add(userL);

        // Disk Panel
        JPanel diskPanel = new JPanel();
        diskPanel.setBounds(100,150,400,100);
        f2.add (diskPanel);
        addDiskToPanel(diskPanel);

        Toolkit t3 = Toolkit.getDefaultToolkit();
        JLabel diskL = new JLabel("");
        Image diskImg = t3.getImage("resources/disk.png");
        diskL.setIcon(new ImageIcon(diskImg));
        diskL.setBounds(10,125,100,100);
        f2.add(diskL);

        // Printer Panel
        JPanel printPanel = new JPanel();
        printPanel.setBounds(100,300,400,100);
        f2.add(printPanel);
        addPrinterToPanel(printPanel);

        Toolkit t4 = Toolkit.getDefaultToolkit();
        JLabel printerL = new JLabel("");
        Image printerImg = t4.getImage("resources/printer1.png");
        printerL.setIcon(new ImageIcon(printerImg));
        printerL.setBounds(10,275,100,100);
        f2.add(printerL);
        // End Frame

        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}