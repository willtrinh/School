import java.io.FileNotFoundException;
import java.io.IOException;

public class Main
{
    public static void main(String[] args) throws IOException, InterruptedException
    {
        GUI.createGUI();

        for (int i = 0; i < OS.NUMBER_OF_USERS; i++)
            OS.users[i] = new UserThread(i + 1);

        for (int i = 0; i < OS.NUMBER_OF_DISKS; i++)
            OS.disks[i] = new Disk();

        for (int i = 0; i < OS.NUMBER_OF_PRINTERS; i++)
            OS.printers[i] = new Printer(i + 1);

        for (int i = 0; i < OS.NUMBER_OF_USERS; i++)
        {
            OS.users[i].start();
        }

    }
}
