import java.io.IOException;
import javax.swing.JLabel;
public class OS
{
    public static final int NUMBER_OF_USERS = 4;
    public static final int NUMBER_OF_DISKS = 2;
    public static final int NUMBER_OF_PRINTERS = 3;

    public static UserThread[] users = new UserThread[NUMBER_OF_USERS];
    public static Disk[] disks = new Disk[NUMBER_OF_DISKS];
    public static Printer[] printers = new Printer[NUMBER_OF_PRINTERS];

    public static JLabel[] userUI = new JLabel[NUMBER_OF_USERS];
    public static JLabel[] userUI2 = new JLabel[NUMBER_OF_USERS];
    public static JLabel[] diskUI = new JLabel[NUMBER_OF_DISKS];
    public static JLabel[] printerUI = new JLabel[NUMBER_OF_PRINTERS];

    public static ResourceManager diskManager = new ResourceManager(NUMBER_OF_DISKS);
    public static ResourceManager printerManager = new ResourceManager(NUMBER_OF_PRINTERS);
    public static DirectoryManager directoryManager = new DirectoryManager();
    public static DiskManager dManager = new DiskManager();
}
