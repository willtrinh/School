import java.io.IOException;

class PrintJobThread extends Thread
{
    private String fn;
    StringBuffer buf = new StringBuffer();
    private FileInfo file;

    PrintJobThread(FileInfo f)
    {
        this.file = f;
        //file = OS.dManager.dm.lookup(fn);
    }

    public void run()
    {
        // Request printer
        int printerID = 0;
        try {
            printerID = OS.printerManager.request();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        for (int i = 0; i < file.fileLength; i++)
        {
            try {
                OS.disks[file.diskNumber].read(file.startingSector + i, buf);
                System.out.println("Disk " + (file.diskNumber+1) + " is reading data " + buf.toString());
                GUI.updatePanel("Disk " + (file.diskNumber+1) + ": Reading data " + buf.toString(), OS.diskUI[file.diskNumber]);

                OS.printers[printerID].print(buf);
                System.out.println("Printer " + (printerID+1) + " is printing data " + buf.toString());
                GUI.updatePanel("Printer " + (printerID+1) +": Printing " + buf.toString(), OS.printerUI[printerID]);
            } catch (IOException e)
            {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        GUI.updatePanelInactive("Disk " + (file.diskNumber+1) + ": Inactive", OS.diskUI[file.diskNumber]);
        OS.printerManager.release(printerID);
        GUI.updatePanelInactive("Printer " + (printerID+1) + ": Inactive", OS.printerUI[printerID]);
    }
}
