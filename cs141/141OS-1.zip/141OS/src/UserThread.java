// Each user reads from USERi
// Each USERi file contains 3 commands:
    // .save X
    // .end
    // .print X
// Handles saving files to disk.
// Create a new PrintJobThread to handle each print request.
// Can have only 1 local StringBuffer for current line of text.

import javax.swing.*;
import java.awt.*;
import java.io.*;

class UserThread extends Thread
{
    StringBuffer s = new StringBuffer("USER");
    StringBuffer buffer;
    BufferedReader file;
    private int userID;

    UserThread(int id) throws IOException
    {
        try {
            userID = id;
            s.append(Integer.toString(id));
            // C:\Users\William\Downloads\Dev\cs141\hw8\141OS\inputs\
            FileReader fr = new FileReader("inputs/" + s.toString());
            file = new BufferedReader(fr);
            buffer = new StringBuffer();
        } catch(Exception e)
        {
            System.out.println("Can't Open File.");
        }
    }

    boolean readLine() throws IOException {
        String line;

        try {
            line = file.readLine();
            if (line == null || line == " \n")
                return false;
            buffer = new StringBuffer(line);
            return true;
        } catch(Exception e)
        {
            e.printStackTrace();
        }

        return false;
    }

    @Override
    public void run() {
        try {
            while (readLine())
            {
//                System.out.println(buffer.toString());
//                System.out.println(Integer.toString(buffer.length()));
                if (buffer.substring(0,5).equals(".save"))
                {
                    String command = buffer.substring(6);
                    StringBuffer fn = new StringBuffer(command);
                    FileInfo file = new FileInfo();
                    file.fileLength = 0;
                    file.diskNumber = OS.diskManager.request();
                    file.startingSector = OS.dManager.getNextSector(file.diskNumber);
                    System.out.println("User " + userID + " created file " + command + " on disk" + (file.diskNumber+1));
                    GUI.updatePanel("User " + userID + ": Created file " + command + " on disk" + (file.diskNumber+1), OS.userUI[userID-1]);
                    readLine();
                    System.out.println("User " + userID + " is writing data " + buffer.toString() + " to file " + command + " on disk" + (file.diskNumber+1));
                    GUI.updatePanel("User " + userID + ": Writing data " + buffer.toString() + " to file " + command + " on disk" + (file.diskNumber+1), OS.userUI[userID-1]);

                    while (!buffer.substring(0,4).equals(".end"))
                    {
                        OS.disks[file.diskNumber].write(file.startingSector + file.fileLength,buffer);
                        System.out.println("Disk " + (file.diskNumber+1) + " is writing data " + buffer.toString());
                        GUI.updatePanel("Disk " + (file.diskNumber+1) + ": Writing data " + buffer.toString(), OS.diskUI[file.diskNumber]);

                        file.fileLength++;
                        readLine();
                    }
                    OS.dManager.dm.enter(fn.toString(),file);
                    // Release block
                    OS.diskManager.release(file.diskNumber);
                    GUI.updatePanelInactive("Disk " + (file.diskNumber+1) + ": Inactive", OS.diskUI[file.diskNumber]);

                }
                else if(buffer.substring(0,6).equals(".print"))
                {
                    String fn = buffer.substring(7);
                    FileInfo file = OS.dManager.dm.lookup(fn);
                    PrintJobThread p = new PrintJobThread(file);
                    (new PrintJobThread(file)).start();
                    GUI.updatePanelInactive("User " + userID + ": Inactive", OS.userUI[userID-1]);
//                    FileInfo file = OS.dManager.dm.lookup(buffer.substring(7));
//                    for (int i = 0;i<file.fileLength;i++)
//                    {
//                        OS.disks[file.diskNumber].read(file.startingSector + i,buffer);
//                        OS.printers[0].print(buffer);
//
//                    }
                }
            }
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
}
