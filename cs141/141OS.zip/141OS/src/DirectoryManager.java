// DirectoryManager maps file names into disk sectors.
// Knows where files are stored on disk.
import java.util.Hashtable;

class DirectoryManager
{
    Hashtable<String, FileInfo> T = new Hashtable<>();
    void enter(String key, FileInfo file)
    {
        T.put(key, file);
    }

    FileInfo lookup(String key)
    {
        return T.get(key);
    }
}