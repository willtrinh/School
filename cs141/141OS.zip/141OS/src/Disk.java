// Can only read/write 1 line at a time
// To store a file, must issue a write for each input line.
// Reads/Writes each take 200 ms (Thread.sleep(200))
// before copying the data to/from disk sector

class Disk
{
    int currentSector;
    static final int NUM_SECTORS = 1024;
    StringBuffer sectors[] = new StringBuffer[NUM_SECTORS];

    Disk()
    {
        currentSector = 0;

        for (int i = 0; i < NUM_SECTORS; i++)
            sectors[i] = new StringBuffer(NUM_SECTORS);
    }

    void write(int sector, StringBuffer data)
    {
        try {
            sectors[sector] = new StringBuffer(data.toString());
            currentSector += 1;
            Thread.sleep(200);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    StringBuffer read(int sector, StringBuffer data)
    {
        try {
            data.setLength(0);
            data.append(sectors[sector].toString());
            Thread.sleep(200);
        } catch(InterruptedException e){
            e.printStackTrace();
        }
        return data;
    }
}