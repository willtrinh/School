// A FileInfo object holds disk number, file length (in sectors), and..
// the index of starting sector.

class FileInfo
{
    int diskNumber;
    int startingSector;
    int fileLength;
}
