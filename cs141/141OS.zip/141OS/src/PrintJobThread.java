import java.io.IOException;

class PrintJobThread extends Thread
{
    private String fn;
    StringBuffer buf = new StringBuffer();
    FileInfo file;

    PrintJobThread(String fileName)
    {
        fn = fileName;
        file = OS.dManager.dm.lookup(fn);
    }

    public void run()
    {
        // Request printer
        int printerID = 0;
        try {
            printerID = OS.printerManager.request();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        for (int i = 0; i < file.fileLength; i++)
        {
            buf = OS.disks[file.diskNumber].read(file.startingSector + i, buf);
            try {
                OS.printers[printerID].print(buf);
                System.out.println("Printer " + printerID + " is printing data " + buf.toString());
            } catch (IOException e)
            {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        OS.printerManager.release(printerID);
    }
}
