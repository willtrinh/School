// Each printer writes data to a file named PRINTERi (i = index of printer)
// A printer can handle 1 line of text at a time
// Takes 2750 ms to print (Thread.sleep(2750))

import java.io.*;

public class Printer
{
    StringBuffer sbuf = new StringBuffer("PRINTER");

    public Printer(int printerID)
    {
        sbuf.append(Integer.toString(printerID));
    }

    void print(StringBuffer buf) throws InterruptedException, IOException
    {
//        BufferedWriter writer = null;
        try {
            FileWriter fw = new FileWriter("outputs/" + sbuf.toString(),true);
            BufferedWriter writer = new BufferedWriter(fw);
            writer.write(buf.toString()+"\n");
            // sleep 2750 ms before next print.
            Thread.sleep(2750);
            // flush after each write
            writer.flush();
            writer.close();
        } catch(Exception e) {
            e.printStackTrace();
        }

    }
}
